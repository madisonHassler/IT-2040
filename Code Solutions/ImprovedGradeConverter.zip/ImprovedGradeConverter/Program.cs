﻿using System;
using System.Collections.Generic;

namespace ImprovedGradeConverter
{
    class Program
    {
        static void Main(string[] args)
        {
            bool doAgain = true;
            string moreConversions;
            int numberOfGrades;

            //Ask the user to enter their first and last name
            string userName = getName();

            //Print a welcome message: "Hello [first name] [last name] Welcome to the Grade Converter!"
            Console.WriteLine($"\nHello {userName}! Welcome to the Grade Converter!");

            while(doAgain){
                List<float> scores = new List<float>();
                //get number of grades
                numberOfGrades = getNumberOfGrades();
                //populate the scores list
                scores = populateGradesList(scores, numberOfGrades); 
                //print grades report
                printGradesReport(scores);
                //print grade statistics
                printGradeStatistics(scores, numberOfGrades);

                //ask user if they would like to continue
                Console.WriteLine("Would you like to convert nore grades (y/n)?");
                moreConversions = Console.ReadLine();

                if (moreConversions != "y" && moreConversions != "Y"){
                    doAgain = false;
                }
            }
        }

        /*
        Function that prints grade statistics
        Input: List<float> scoresList, (int) numberOfGrades
        Output: none
        */
        static void printGradeStatistics(List<float> scoresList, int numberOfGrades){
            float averageScore = getAverageGrade(scoresList) ;
            Console.WriteLine("\nGrade Statistics\n-------------------------\n");
            Console.WriteLine($"Number of grades: {numberOfGrades}");
            Console.WriteLine($"Average Grade: {averageScore} which is a {getLetterGrade(averageScore)}");
            Console.WriteLine($"Highest Grade: {getMaximumGrade(scoresList)}");
            Console.WriteLine($"Lowest Grade: {getMinimumGrade(scoresList)}");
            return;
        }

        /*
        Function that determines the minimum grade from a list of grades
        Input: List<float> scoresList
        Output: minimum score(float)
        */
        static float getMinimumGrade(List<float> scoresList){
            float minScore = scoresList[0];
            foreach(float score in scoresList){
                if (score < minScore){
                    minScore = score;
                }
            }
            return minScore;
        }

        /*
        Function that determines the maximum grade from a list of grades
        Input: List<float> scoresList
        Output: maximum score(float)
        */
        static float getMaximumGrade(List<float> scoresList){
            float maxScore = scoresList[0];
            foreach(float score in scoresList){
                if (score > maxScore){
                    maxScore = score;
                }
            }
            return maxScore;
        }

        /*
        Function that alculates the average grade from a list of grades
        Input: List<float> scoresList
        Output: average grade(float)
        */
        static float getAverageGrade(List<float> scoresList){
            float totalScore = 0;
            foreach (float score in scoresList){
                totalScore += score;
            }
            return (totalScore / scoresList.Count);
        }

        /*
        Function that prints a grade report
        Input: List<float> scoresList
        Output: none
        */
        static void printGradesReport(List<float> scoresList){
            Console.WriteLine();
            string letterGrade;
            
            foreach(float testScore in scoresList){
                //Convert the number grades to letter grades (A = 90-100, B = 80-89, C = 70-79, D = 60 - 69, F lower than 60)
                letterGrade = getLetterGrade(testScore);
                //Print all the numerical grades and their corresponding letter grades to the console 
                Console.WriteLine($"A score of {testScore} is a {letterGrade} grade"); 
            }
            return;
        }

        /*
        Function that populates a list of type float
        Input: List<float> scoresList, numGrades(int)
        Output: List<float> scoresList
        */
        static List<float> populateGradesList(List<float> scoresList, int numGrades){
            float score;
            
            for(int counter = 0; counter < numGrades; counter ++){
                    score = getScores();
                    scoresList.Add(score);
                }
                return scoresList;
        }

         /*
        Function that prompts a user to enter the number of grades to be converted
        Input: None
        Output: (int)numGrades
        */
        static int getNumberOfGrades(){
            Console.WriteLine("\nEnter the number of grades you need to convert:");
            int numGrades = int.Parse(Console.ReadLine());
            return numGrades;
        }

        /*
        Function that prompts a user to enter their name
        Input: None
        Output: (string)userName
        */
        static string getName(){
            Console.WriteLine("Please enter your first name and last name");
            string userName = Console.ReadLine();
            return userName;
        }

        /*
        Function that prompts a user to enter a score to be converted
        Input: None
        Output: (float)grade
        */
        static float getScores(){
            float grade;
            while(true){
                Console.WriteLine("\nEnter the score to be converted: ");
                try{
                    grade = float.Parse(Console.ReadLine());
                    if(grade < 0){
                        Console.WriteLine("Error: Value must be greater than 0");
                        continue;
                    }
                    break;  
                }catch(FormatException){
                    Console.WriteLine("Error: Only numbers allowed");
                }
            }  
            return grade;
        }

        /*
        Function that converts a number grade to a letter grade
        Input: (float) score
        Output: (string )letter grade
        */
        static string getLetterGrade(float score){
            //(A = 90-100, B = 80-89, C = 70-79, D = 60 - 69, F lower than 60).
            if (score >= 90){
                return "A";
            }else if(score >= 80){
                return "B";
            }else if (score >= 70){
                return "C";
            }else if(score >= 60){
                return "D";
            }else{
                return "F";
            }
        }

    }
}
